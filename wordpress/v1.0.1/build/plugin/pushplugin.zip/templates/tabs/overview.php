<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.'); ?>
<div class="mx-auto w-full logo-top text-white text-5xl font-bold text-center pt-10 pb-20 -mb-14">
  <?= ($all_subscribers == 0)
  ?'🙋‍♂️ <span class="font-extrabold hidden md:inline">Start Collecting Subscribers Now!</span><span class="md:hidden leading-10" style="line-height:3.5rem">Start Collecting Subscribers!</span>'
  :'🙋‍♂️ <span class="hidden md:inline">You Earned <span class="font-extrabold">'.$today_subscribers.'</span> Subscribers Today</span><span class="md:hidden leading-10" style="line-height:3.5rem">Collected<br><span class="font-extrabold">'.$today_subscribers.'</span><br>Subs Today</span>' ?>
</div>
<main class="grow">
  <div class="px-4 mx-auto max-w-8xl lg:px-4">
    <div class="border-gray-200 px-2 sm:px-4 pt-2.5 rounded dark:bg-gray-900">
      <div class="mx-auto">
        <div class="mb-6 w-full">
        <?php include(MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/trial-alert.php'); ?>
        </div>
        <div class="mb-6 w-full">
          <div class="flex flex-col justify-between items-center p-4 bg-white rounded-lg border border-gray-200 shadow-sm dark:bg-gray-800 dark:border-gray-700 sm:flex-row h-60">
            <canvas id="myChart"></canvas>
          </div>
        </div>
        <div>
          <div class="overflow-x-auto relative shadow-md sm:rounded-lg mt-4">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
              <caption class="p-5 text-lg font-semibold text-left text-gray-900 bg-white dark:text-white dark:bg-gray-800">
                Recent Campaigns
                <p class="mt-1 text-sm font-normal text-gray-500 dark:text-gray-400">See your recent 5
                  campaigns here, and plan send push notification accordingly</p>
              </caption>
              <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" class="py-3 px-6">Title</th>
                  <th scope="col" class="py-3 px-6">Status</th>
                  <th scope="col" class="py-3 px-6">Success</th>
                  <th scope="col" class="py-3 px-6">Unsubscribed</th>
                  <!-- <th scope="col" class="py-3 px-6">Clicks</th> -->
                  <th scope="col" class="py-3 px-6">Actions</th>
                  <th scope="col" class="py-3 px-6">Created at</th>
                </tr>
              </thead>
              <tbody>
                <!-- Add php code to fetch data from database -->
                <?php foreach ($results as $result) { ?>
                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                  <td class="py-4 px-6 whitespace-nowrap"><?= $result->title ?></td>
                  <td class="py-4 px-6 whitespace-nowrap"><?= $result->status ?></td>
                  <td class="py-4 px-6 whitespace-nowrap"><?= $result->success ?></td>
                  <td class="py-4 px-6 whitespace-nowrap"><?= $result->failure ?></td>
                  <!-- <td class="py-4 px-6 whitespace-nowrap"><?= $result->ctr ?></td> -->
                  <td class="py-4 px-6 whitespace-nowrap flex flex-row gap-2">
                    <button onclick="clonePush(<?= $result->id ?>)">
                      <div class="px-3 py-2 text-xs font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z">
                          </path>
                        </svg>
                      </div>
                    </button>
                    <a href="<?= add_query_arg(array('action' => 'pushplugin_trash_notification', 'id' => $result->id), admin_url( 'admin.php' ) ) ?>">
                      <div class="px-3 py-2 text-xs font-medium text-center text-white bg-red-700 rounded-lg hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                          </path>
                        </svg>
                      </div>
                    </a>
                  </td>
                  <td class="py-4 px-6 whitespace-nowrap"><?= $result->created_at ?></td>
                </tr>
                <?php } ?>

                <?php if (empty($results)) { ?>
                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                  <td class="py-4 px-6 whitespace-nowrap text-center" colspan="7">No data found</td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  function drawGraph() {
    // number of bars
    var barCount = Math.floor(window.innerWidth / 80);
    if (barCount > 20) {
      barCount = 20;
    }

    const last20days = <?= json_encode($last_20_days); ?>;

    var dataInChart = {};
    for (var i = 0; i < barCount; i++) {
      countForDate = last20days.find(x => x.date === moment().subtract(i, 'days').format('YYYY-MM-DD'));
      if (countForDate) {
        dataInChart[moment().subtract(i, 'days').format('MMM D')] = countForDate.count;
      } else {
        dataInChart[moment().subtract(i, 'days').format('MMM D')] = 0;
      }
    }
    dataInChart = Object.fromEntries(
      Object.entries(dataInChart).reverse()
    );
    var nextDay = 1;
    for (var key in dataInChart) {
      if (dataInChart[key] == 0) {
        delete dataInChart[key];
        dataInChart[moment().add(nextDay, 'days').format('MMM D')] = 0;
        nextDay++;
      } else {
        break;
      }
    }

    const ctx = document.getElementById("myChart");

    // create a bar chart with the chart.js library and full width of myChart container with a width of 100px
    const myChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: Object.keys(dataInChart),
        datasets: [{
          label: "Subscribers collected",
          data: Object.values(dataInChart),
          backgroundColor: "#1a56db",
          borderRadius: 4,
          barPercentage: 0.7,
          maxBarThickness: 50,
        }, ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
            grid: {
              display: false,
              tickWidth: 0,
            },
            ticks: {
              min: 0, // it is for ignoring negative step.
              beginAtZero: true,
              callback: function (value, index, values) {
                if (Math.floor(value) === value) {
                  return value;
                }
              }
            }
          },
          x: {
            grid: {
              display: false,
              tickWidth: 0,
            },
          },
        },
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
        },
      },
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    drawGraph();
  });
</script>