<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.'); ?>
<div class="mx-auto w-full logo-top text-white text-5xl font-bold text-center pt-10 pb-20 -mb-14">
  <?php include(MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/icon.php') ?>
  <div class="px-8">
    <?= (!$header)? 'Step 2 of 2:' : '' ?>
    Create Notification
    <div class="inline">
      <svg height="50px" viewBox="0 0 1024 1024" class="icon inline" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <path d="M862.90625 932.1875H162.96875c-38.71875 0-70.125-31.40625-70.125-70.125V432.5c0-38.71875 31.40625-70.125 70.125-70.125h699.9375c38.71875 0 70.125 31.40625 70.125 70.125v429.5625c0 38.71875-31.40625 70.125-70.125 70.125z" fill="#00AAFF" />
        <path d="M784.0625 227.5625H239.9375c-32.4375 0-58.78125 26.34375-58.78125 58.78125v45.9375h661.6875v-45.9375c0-32.53125-26.34375-58.78125-58.78125-58.78125z" fill="#FC592D" />
        <path d="M721.25 91.34375H306.59375c-32.4375 0-58.78125 26.34375-58.78125 58.78125v45.9375H780.125v-45.9375c-0.09375-32.4375-26.34375-58.78125-58.875-58.78125z" fill="#FFCE00" />
      </svg>
    </div>
  </div>
</div>
<main class="grow">
  <div class="px-4 mx-auto max-w-8xl lg:px-4">
    <div class="border-gray-200 px-2 sm:px-4 pt-2.5 rounded dark:bg-gray-900">
      <div class="mx-auto">
        <?php include(MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/trial-alert.php'); ?>
        <div>
          <div class="grid grid-cols-1 md:grid-cols-2 md:space-x-4">
            <div class="flex flex-col justify-between items-center p-8 bg-gray-50 rounded-lg border border-gray-200 shadow-sm dark:bg-gray-800 dark:border-gray-700 sm:flex-row">
              <form class="w-full" method="post" onsubmit="return send_custom_push(event)">
                <div class="mb-6">
                  <label for="title" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Title (💡 Small and catchy)</label>
                  <input type="text" id="title" name="title" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="body" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Body (💡 Something that creates curiosity)</label>
                  <input type="text" id="body" name="body" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="icon" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Icon</label>
                  <input type="text" id="icon" name="icon" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="image" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Image</label>
                  <input type="text" id="image" name="image" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" />
                </div>
                <div class="mb-6">
                  <label for="url" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Click URL (Should Start with <span class="website-name"></span>)</label>
                  <input type="text" id="url" name="url" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <button type="button" class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700" onclick="resetCustomNotification()">Reset</button>
                <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Send Notification</button>
              </form>
            </div>
            <div id="notification-preview" class="pointer-events-none min-h-96 mt-4 md:mt-0 flex flex-col justify-between items-center bg-gray-50 rounded-lg border overflow-hidden border-gray-200 shadow-sm dark:bg-gray-800 dark:border-gray-700 sm:flex-row min-h-[500px]">
              <div class="pp_mobile">
                <div class="notification-cover" style="margin: auto">
                  <div class="meta">
                    <div class="favicon">
                      <img src="https://cdn.pushplugin.com/wordpress/v1.0.0/icon-bell.svg" style="height:20px">
                    </div>
                    <div class="app-name">Chrome</div>
                    <div class="dot"></div>
                    <div class="website-name"></div>
                    <div class="dot"></div>
                    <div class="time">now</div>
                    <div class="arrow-top"><svg width="7" height="6" viewBox="0 0 6 5" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0.705 4.35248L3 2.06248L5.295 4.35248L6 3.64748L3 0.647478L6.16331e-08 3.64748L0.705 4.35248Z" fill="#212121"></path>
                      </svg></div>
                  </div>
                  <div class="title"></div>
                  <div class="body"></div>
                  <div class="image">
                    <img src="" width="100%">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
  function updatePopup() {
    const websiteName = window.location.hostname;

    const title = document.querySelector('#title');
    const body = document.querySelector('#body');
    const image = document.querySelector('#image');
    const icon = document.querySelector('#icon');
    const url = document.querySelector('#url');

    document.querySelector('.website-name').innerHTML = '<code>https://' + websiteName + '</code>';
    document.querySelector('.pp_mobile .website-name').innerHTML = websiteName;
    document.querySelector('.pp_mobile .title').innerHTML = title.value;
    document.querySelector('.pp_mobile .body').innerHTML = body.value;
    document.querySelector('.pp_mobile .image img').src = image.value;
    document.querySelector('.pp_mobile .favicon img').src = icon.value;

  }

  function resetCustomNotification(){
    document.querySelector('#title').value = '<?= get_bloginfo('name') ?>';
    document.querySelector('#body').value = '<?= get_bloginfo('description') ?>';
    document.querySelector('#icon').value = 'https://cdn.pushplugin.com/wordpress/v1.0.0/icon-bell.svg';
    document.querySelector('#image').value = 'https://via.placeholder.com/468x220?text=Sample Image';
    document.querySelector('#url').value = 'https://' + window.location.hostname + '/';
    document.querySelector('#url').value = 'https://' + window.location.hostname + '/';

    updatePopup();
  }

  document.querySelectorAll('input').forEach((input) => {
    input.addEventListener('input', updatePopup);
  });

  function send_custom_push(event) {
    event.preventDefault();
    const title = document.querySelector('#title');
    const body = document.querySelector('#body');
    const icon = document.querySelector('#icon');
    const image = document.querySelector('#image');
    const url = document.querySelector('#url');

    parent.postMessage({
      action: "turnOffLoading"
    }, '*')
    customPush(title.value, body.value, icon.value, image.value, url.value);
  }

  resetCustomNotification()
</script>