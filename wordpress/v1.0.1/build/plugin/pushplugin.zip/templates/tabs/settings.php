<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.'); ?>
<div class="mx-auto w-full logo-top text-white text-5xl font-bold text-center pt-10 pb-20 -mb-14">
  <?php include(MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/icon.php') ?>
  <div class="px-8">
    <?= (!$header)? 'Step 1 of 2:' : '' ?>
    Setup Firebase
    <div class="inline">
      <svg height="40" class="inline" viewBox="0 0 256 351" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid">
        <defs>
          <path d="M1.253 280.732l1.605-3.131 99.353-188.518-44.15-83.475C54.392-1.283 45.074.474 43.87 8.188L1.253 280.732z" id="a" />
          <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="b">
            <feGaussianBlur stdDeviation="17.5" in="SourceAlpha" result="shadowBlurInner1" />
            <feOffset in="shadowBlurInner1" result="shadowOffsetInner1" />
            <feComposite in="shadowOffsetInner1" in2="SourceAlpha" operator="arithmetic" k2="-1" k3="1" result="shadowInnerInner1" />
            <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0" in="shadowInnerInner1" />
          </filter>
          <path d="M134.417 148.974l32.039-32.812-32.039-61.007c-3.042-5.791-10.433-6.398-13.443-.59l-17.705 34.109-.53 1.744 31.678 58.556z" id="c" />
          <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="d">
            <feGaussianBlur stdDeviation="3.5" in="SourceAlpha" result="shadowBlurInner1" />
            <feOffset dx="1" dy="-9" in="shadowBlurInner1" result="shadowOffsetInner1" />
            <feComposite in="shadowOffsetInner1" in2="SourceAlpha" operator="arithmetic" k2="-1" k3="1" result="shadowInnerInner1" />
            <feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.09 0" in="shadowInnerInner1" />
          </filter>
        </defs>
        <path d="M0 282.998l2.123-2.972L102.527 89.512l.212-2.017L58.48 4.358C54.77-2.606 44.33-.845 43.114 6.951L0 282.998z" fill="#FFC24A" />
        <use fill="#FFA712" fill-rule="evenodd" xlink:href="#a" />
        <use filter="url(#b)" xlink:href="#a" />
        <path d="M135.005 150.38l32.955-33.75-32.965-62.93c-3.129-5.957-11.866-5.975-14.962 0L102.42 87.287v2.86l32.584 60.233z" fill="#F4BD62" />
        <use fill="#FFA50E" fill-rule="evenodd" xlink:href="#c" />
        <use filter="url(#d)" xlink:href="#c" />
        <path fill="#F6820C" d="M0 282.998l.962-.968 3.496-1.42 128.477-128 1.628-4.431-32.05-61.074z" />
        <path d="M139.121 347.551l116.275-64.847-33.204-204.495c-1.039-6.398-8.888-8.927-13.468-4.34L0 282.998l115.608 64.548a24.126 24.126 0 0 0 23.513.005" fill="#FDE068" />
        <path d="M254.354 282.16L221.402 79.218c-1.03-6.35-7.558-8.977-12.103-4.424L1.29 282.6l114.339 63.908a23.943 23.943 0 0 0 23.334.006l115.392-64.355z" fill="#FCCA3F" />
        <path d="M139.12 345.64a24.126 24.126 0 0 1-23.512-.005L.931 282.015l-.93.983 115.607 64.548a24.126 24.126 0 0 0 23.513.005l116.275-64.847-.285-1.752-115.99 64.689z" fill="#EEAB37" />
      </svg>
    </div>
  </div>
</div>
<main class="grow">
  <div class="px-4 mx-auto max-w-8xl lg:px-4">
    <div class="border-gray-200 px-2 sm:px-4 pt-2.5 rounded dark:bg-gray-900">
      <div class="mx-auto">
        <div>
          <div class="grid grid-cols-1 md:grid-cols-2 md:space-x-4">
            <div class="flex flex-col justify-between items-center p-8 bg-gray-50 rounded-lg border border-gray-200 shadow-sm dark:bg-gray-800 dark:border-gray-700 sm:flex-row">
              <form class="w-full" method="post" action="<?= admin_url('admin-post.php') ?>">
                <input type="hidden" name="action" value="pushplugin_save_settings">
                <?php wp_nonce_field('pushplugin_save_settings') ?>
                <div class="mb-6">
                  <label class="inline-flex relative items-center mb-4 cursor-pointer">
                    <input type="checkbox" name="enabled" id="enabled" class="sr-only peer" value="1" <?= ($enabled) ? 'checked' : '' ?> />
                    <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600">
                    </div>
                    <span class="ml-3 text-sm font-medium text-gray-900 dark:text-white block">Enable PushPlugin On Website</span>
                  </label>
                </div>
                <?php if($header){ ?>
                  <div class="mb-6">
                    <label for="license_key" class="block mb-2 text-sm font-bold text-gray-900 dark:text-white">PushPlugin License <span class="text-red-600"><?= ($trial)? '(Trial)' : ''; ?></span></label>
                    <input value="<?= get_option('pushplugin_license_trial')? '' : '**********************************' ?>" type="text" name="license_key" id="license_key" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                    <div class="text-xs text-left mt-1">
                      <?php if($licenseValidity < 0){ ?>
                        <p class="text-red-600">Your license has expired. <a href="https://pushplugin.com/pricing?utm_source=wordpress&utm_medium=plugin&utm_campaign=settings-page&utm_content=renew" class="font-bold">Renew Now! →</a></p> 
                      <?php }else if($licenseValidity < 7){ ?>
                        <p class="text-red-600">Your license will expire in <?= $licenseValidity ?> days. <a href="https://pushplugin.com/pricing?utm_source=wordpress&utm_medium=plugin&utm_campaign=settings-page&utm_content=extend-now-red" class="font-bold">Extend Now! →</a></p>
                      <?php }else{ ?>
                        <p><span class="text-green-600">Will expire in <?= $licenseValidity ?> days</a>. <a href="https://pushplugin.com/pricing?utm_source=wordpress&utm_medium=plugin&utm_campaign=settings-page&utm_content=extend-now-green" class="font-bold">Extend Now! →</a></p>
                      <?php } ?>
                      </div>
                  </div>
                <?php } ?>
                <div class="mb-6">
                  <label for="firebase_api_key" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Firebase API Key</label>
                  <input value="<?= get_option('pushplugin_firebase_api_key')? get_option('pushplugin_firebase_api_key') : '' ?>" type="text" name="firebase_api_key" id="firebase_api_key" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="firebase_project_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Firebase Project ID</label>
                  <input value="<?= get_option('pushplugin_firebase_project_id')? get_option('pushplugin_firebase_project_id') : '' ?>" type="text" name="firebase_project_id" id="firebase_project_id" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="firebase_messaging_sender_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Firebase Messaging Sender ID</label>
                  <input value="<?= get_option('pushplugin_firebase_messaging_sender_id')? get_option('pushplugin_firebase_messaging_sender_id') : '' ?>" type="text" name="firebase_messaging_sender_id" id="firebase_messaging_sender_id" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="firebase_app_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Firebase App ID</label>
                  <input value="<?= get_option('pushplugin_firebase_app_id')? get_option('pushplugin_firebase_app_id') : '' ?>" type="text" name="firebase_app_id" id="firebase_app_id" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="firebase_server_key" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Firebase Server Key</label>
                  <input value="<?= get_option('pushplugin_firebase_server_key')? get_option('pushplugin_firebase_server_key') : '' ?>" type="text" name="firebase_server_key" id="firebase_server_key" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="firebase_public_key" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Firebase Public Key</label>
                  <input value="<?= get_option('pushplugin_firebase_public_key')? get_option('pushplugin_firebase_public_key') : '' ?>" type="text" name="firebase_public_key" id="firebase_public_key" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="firebase_private_key" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Firebase Private Key</label>
                  <input value="<?= get_option('pushplugin_firebase_private_key')? get_option('pushplugin_firebase_private_key') : '' ?>" type="text" name="firebase_private_key" id="firebase_private_key" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <button type="button" class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">Reset</button>
                <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Save Configuration</button>
              </form>
            </div>
            <div id="documentation" class="bg-gray-50 border overflow-hidden mt-4 md:mt-0 flex flex-col justify-between items-center rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700 sm:flex-row min-h-[500px]">
              <iframe width="100%" height="100%"></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
  // on page load open the link in the iframe
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      const iframe = document.querySelector('iframe');
      iframe.src = '<?= $settings_pdf ?>';
    }, 1000);
  });
</script>