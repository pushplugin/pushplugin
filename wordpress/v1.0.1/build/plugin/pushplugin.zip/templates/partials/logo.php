<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.'); ?>
<div class="hidden md:block">
    <a href="https://pushplugin.com/?utm_source=wordpress&utm_medium=plugin&utm_campaign=logo&utm_content=pushplugin-logo" target="_blank" class="flex items-center relative">
        <img src="https://cdn.pushplugin.com/wordpress/logo-full.svg" class="h-10" alt="pushplugin logo" />
    </a>
</div>
<div class="md:hidden block">
    <a href="https://pushplugin.com/?utm_source=wordpress&utm_medium=plugin&utm_campaign=logo&utm_content=pushplugin-logo" target="_blank" class="flex items-center relative">
        <img src="https://cdn.pushplugin.com/wordpress/icon-red.svg" class="h-10" alt="pushplugin logo" />
    </a>
</div>