<?php if($trial){ ?>
  <div id="alert-additional-content-2" class="p-4 mb-4 text-red-800 border border-red-300 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400 dark:border-red-800" role="alert">
    <div class="flex items-center">
      <svg aria-hidden="true" class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path>
      </svg>
      <span class="sr-only">Info</span>
      <h3 class="text-lg font-medium">You are on Trial!</h3>
    </div>
    <div class="mt-2 mb-4 text-sm">
      Your trial will expire in <span class="font-bold"><?= $expiry ?></span>. Please purchase a plan to continue using the plugin.<br>You will get logged out once your trial expires <b>your subscriber data might get lost.</b>
    </div>
    <div class="flex">
      <button onclick="window.open('https://pushplugin.com/pricing?utm_source=wordpress&utm_medium=plugin&utm_campaign=trial&utm_content=buy-license')" type="button" class="cursor-pointer text-white bg-red-800 hover:bg-red-900 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-xs px-3 py-1.5 mr-2 text-center inline-flex items-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">
        <svg aria-hidden="true" class="-ml-0.5 mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <g id="license">
            <g>
              <path d="M6,9C4.3,9,3,7.7,3,6s1.3-3,3-3s3,1.3,3,3S7.7,9,6,9z M6,5C5.4,5,5,5.4,5,6s0.4,1,1,1s1-0.4,1-1S6.6,5,6,5z" />
            </g>
            <g>
              <path d="M24,24h-6.4L15,21.4V20h-3v-3H9v-3.3C8.4,13.9,7.7,14,7,14c-3.9,0-7-3.1-7-7s3.1-7,7-7s7,3.1,7,7c0,0.5,0,1-0.1,1.4 L24,18.6V24z M18.4,22H22v-2.6L11.6,9l0.2-0.6C11.9,8,12,7.5,12,7c0-2.8-2.2-5-5-5S2,4.2,2,7s2.2,5,5,5c0.7,0,1.4-0.1,2.1-0.4 l0.6-0.3l1.3,1.3V15h3v3h3v2.6L18.4,22z" />
            </g>
          </g>
        </svg>
        Buy License
      </button>
      <a onclick="window.open('<?= $tab_links['settings'] ?>', '_self')" type="button" class="cursor-pointer text-red-800 bg-transparent border border-red-800 hover:bg-red-900 hover:text-white focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-xs px-3 py-1.5 text-center dark:hover:bg-red-600 dark:border-red-600 dark:text-red-500 dark:hover:text-white dark:focus:ring-red-800 inline-flex">
        <svg aria-hidden="true" class="-ml-0.5 mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <g id="action">
            <g>
              <path d="M1.7,23.7l-1.4-1.4l2.4-2.4c-2.4-2.8-2.2-7,0.4-9.6l1.7-1.7l10.7,10.7l-1.6,1.6c-1.4,1.4-3.2,2.1-5.1,2.1 c-1.7,0-3.3-0.6-4.6-1.7L1.7,23.7z M5,19.4c1,1,2.3,1.5,3.7,1.5s2.7-0.5,3.7-1.5l0.2-0.2l-7.8-7.9l-0.3,0.3c-2,2-2,5.2,0,7.2 L5,19.4z M19.2,15.3l-2.5-2.5l-2.3,2.3L13,13.8l2.3-2.3l-2.8-2.8L10.2,11L8.8,9.6l2.3-2.3L8.6,4.8l1.6-1.6 c1.4-1.4,3.2-2.1,5.1-2.1c1.7,0,3.3,0.6,4.6,1.7l2.4-2.4l1.4,1.4l-2.4,2.4c2.4,2.8,2.2,7-0.4,9.6L19.2,15.3z M11.4,4.6l7.8,7.9 l0.3-0.3c2-2,2-5.2,0-7.2L19,4.4c-1-1-2.3-1.5-3.7-1.5s-2.7,0.5-3.7,1.5L11.4,4.6z" />
            </g>
          </g>
        </svg>
        Add License
      </a>
    </div>
  </div>
<?php }elseif($licenseValidity < 7){ ?>
  <div id="alert-additional-content-2" class="p-4 mb-4 text-red-800 border border-red-300 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400 dark:border-red-800" role="alert">
    <div class="flex items-center">
      <svg aria-hidden="true" class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path>
      </svg>
      <span class="sr-only">Info</span>
      <h3 class="text-lg font-medium">Your subscription will expire soon.</h3>
    </div>
    <div class="mt-2 mb-4 text-sm">
      Your subscription will expire in <span class="font-bold"><?= $expiry ?></span>. Please renew the plan to continue using the plugin.<br>You will get logged out once your subscription expires <b>your subscriber data might get lost.</b>
    </div>
    <div class="flex">
      <button onclick="window.open('https://pushplugin.com/upgrade?utm_source=wordpress&utm_medium=plugin&utm_campaign=trial&utm_content=upgrade')" type="button" class="cursor-pointer text-white bg-red-800 hover:bg-red-900 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-xs px-3 py-1.5 mr-2 text-center inline-flex items-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">
        <svg aria-hidden="true" class="-ml-0.5 mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <g id="license">
            <g>
              <path d="M6,9C4.3,9,3,7.7,3,6s1.3-3,3-3s3,1.3,3,3S7.7,9,6,9z M6,5C5.4,5,5,5.4,5,6s0.4,1,1,1s1-0.4,1-1S6.6,5,6,5z" />
            </g>
            <g>
              <path d="M24,24h-6.4L15,21.4V20h-3v-3H9v-3.3C8.4,13.9,7.7,14,7,14c-3.9,0-7-3.1-7-7s3.1-7,7-7s7,3.1,7,7c0,0.5,0,1-0.1,1.4 L24,18.6V24z M18.4,22H22v-2.6L11.6,9l0.2-0.6C11.9,8,12,7.5,12,7c0-2.8-2.2-5-5-5S2,4.2,2,7s2.2,5,5,5c0.7,0,1.4-0.1,2.1-0.4 l0.6-0.3l1.3,1.3V15h3v3h3v2.6L18.4,22z" />
            </g>
          </g>
        </svg>
        Upgrade
      </button>
    </div>
  </div>
<?php } ?>