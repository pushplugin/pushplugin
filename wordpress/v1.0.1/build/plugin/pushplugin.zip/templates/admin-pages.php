<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.');?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>PushPlugin</title>
  <meta name="description" content="PushPlugin" />
  <meta name="author" content="Daily Dev Tips" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet" />
  <?php foreach ($styles as $style) {?>
  <link href="<?=$style?>" rel="stylesheet" />
  <?php }?>
</head>

<body class="">
  <div class="flex flex-col min-h-screen relative">
    <?php if ($header) {?>
      <header class="sticky top-0 z-40 flex-none mx-auto w-full bg-white dark:bg-gray-900">
        <div class="px-4 mx-auto max-w-8xl lg:px-4">
          <nav class="bg-white border-gray-200 px-2 sm:px-4 py-2.5 rounded dark:bg-gray-900">
            <div class="flex flex-wrap items-center justify-between mx-auto">
              <?php include MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/logo.php'?>
              <div class="flex md:order-2">
                <div class="flex flex-row gap-3 items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 22" fill="none">
                    <path d="M17 20.7896V18.6623C17 17.534 16.5786 16.4518 15.8284 15.6539C15.0783 14.8561 14.0609 14.4078 13 14.4078H5C3.93913 14.4078 2.92172 14.8561 2.17157 15.6539C1.42143 16.4518 1 17.534 1 18.6623V20.7896" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M9 10.1533C11.2091 10.1533 13 8.24854 13 5.89885C13 3.54917 11.2091 1.64437 9 1.64437C6.79086 1.64437 5 3.54917 5 5.89885C5 8.24854 6.79086 10.1533 9 10.1533Z" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M23 20.7896V18.6623C22.9993 17.7197 22.7044 16.8039 22.1614 16.0589C21.6184 15.3139 20.8581 14.7818 20 14.5461" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M16 1.78264C16.8604 2.01696 17.623 2.5492 18.1676 3.29544C18.7122 4.04169 19.0078 4.9595 19.0078 5.90418C19.0078 6.84885 18.7122 7.76666 18.1676 8.51291C17.623 9.25915 16.8604 9.79139 16 10.0257" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                  <div class="font-bold">
                    <?=$all_subscribers;?>
                  </div>
                  <div class="flex items-center">
                    <div class="h-3 w-3 rounded-full bg-green-400">
                      <span class="animate-ping absolute inline-flex h-3 w-3 rounded-full bg-green-400 opacity-75"></span>
                    </div>
                  </div>
                </div>
                <button data-collapse-toggle="navbar-cta" type="button" class="inline-flex items-center p-3 text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-cta" aria-expanded="false" id="navbar-cta-button">
                  <span class="sr-only">Open main menu</span>
                  <svg class="w-4 h-4" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path>
                  </svg>
                </button>
              </div>
              <div class="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-cta">
                <ul class="flex flex-col p-4 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                  <?php foreach ($navbar_items as $navbar_item) {?>
                  <li>
                    <?php if ($tab == strtolower($navbar_item['name'])) {?>
                    <a href="javascript:void(0)" class="block py-2 pl-3 pr-4 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 dark:text-white" aria-current="tab"><?=$navbar_item['name']?></a>
                    <?php } else {?>
                    <a href="<?=$navbar_item['url']?>" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700 md:p-0 md:dark:hover:text-white dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700" aria-current="tab"><?=$navbar_item['name']?></a>
                    <?php }?>
                  </li>
                  <?php }?>
                  <li>
                    <a href="https://pushplugin.com/report-bugs?utm_source=wordpress&utm_medium=plugin&utm_campaign=navbar&utm_content=report-bugs" target="_blank" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:hover:text-blue-700 md:p-0 md:dark:hover:text-white dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent dark:border-gray-700" aria-current="tab">Report Bugs</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </header>
    <?php }?>
    <?php include MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/tabs/' . $tab . '.php';?>
  </div>
  <?php if ($header) {?>
  <div class="mt-5 mb-5 text-center text-gray-500 text-xs">
    <span class="mr-1">&copy; <?=date('Y')?></span>
    <a href="https://pushplugin.com?utm_source=wordpress&utm_medium=plugin&utm_campaign=footer&utm_content=copyright-pushplugin" target="_blank" class="text-gray-500 hover:underline">PushPlugin</a>
    <span class="mx-1">|</span>
    <span class="mr-1">Version</span>
    <span class="mr-1"><?=$version?></span>
  </div>
  <?php }?>
</body>
<script>
  let pushplugin_nonce = {
    pushplugin_nonce: '<?=wp_create_nonce('pushplugin_nonce')?>'
  }

  let ajaxurl = '<?=admin_url('admin-ajax.php')?>';
</script>
<?php foreach ($scripts as $script) {?>
  <script src="<?=$script?>"></script>
<?php }?>
<script>
  <?php if ($version_data['force_update']) {?>
    var options = <?=json_encode($version_data['swal_data'])?>;
    options.preConfirm = new Function(options.preConfirm?.function?.arguments, options.preConfirm?.function?.body);
    Swal.fire(options);
  <?php }?>
</script>
<script>
  parent.postMessage({action: "changeTab",tab: "<?=$tab?>"}, '*')
</script>
<script src="https://cdn.pushplugin.com/wordpress/v1.0.0/page-plugin.js?ver=<?=round(date('i') / 10) * 10;?>" type="text/javascript"></script>
</html>