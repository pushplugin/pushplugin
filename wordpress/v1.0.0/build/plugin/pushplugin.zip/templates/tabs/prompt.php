<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.'); ?>
<div class="mx-auto w-full logo-top text-white text-5xl font-bold text-center pt-10 pb-20">
  <?php include(MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/icon.php') ?>
  <div class="px-8">
    <?= (!$header)? 'Step 2 of 2:' : '' ?>
    Setup Prompt
    <div class="inline">
      <svg height="50px" viewBox="0 0 1024 1024" class="icon inline" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <path d="M114.8 561.9l-0.8 92.6 151.1-92.6h291.3c39.4 0 71.3-32.6 71.3-72.9V206c0-40.3-31.9-72.9-71.3-72.9H114.8c-39.4 0-71.3 32.6-71.3 72.9v283c0 40.3 31.9 72.9 71.3 72.9z" fill="#9ED5E4" />
        <path d="M114 669.1c-2.5 0-4.9-0.6-7.1-1.9-4.6-2.6-7.4-7.5-7.4-12.7l0.7-79.3C59.8 568.1 29 532.2 29 489V206c0-48.2 38.5-87.4 85.8-87.4h441.5c47.3 0 85.8 39.2 85.8 87.4v283c0 48.2-38.5 87.4-85.8 87.4H269.2l-147.6 90.5c-2.4 1.4-5 2.2-7.6 2.2z m0.8-521.5C83.5 147.6 58 173.8 58 206v283c0 32.2 25.5 58.4 56.9 58.4 3.9 0 7.6 1.5 10.3 4.3 2.7 2.7 4.2 6.5 4.2 10.3l-0.6 66.5 128.8-79c2.3-1.4 4.9-2.1 7.6-2.1h291.3c31.4 0 56.9-26.2 56.9-58.4V206c0-32.2-25.5-58.4-56.9-58.4H114.8z" fill="#154B8B" />
        <path d="M890.1 773.1l1.1 117.4-195.6-117.4H318.4c-51 0-92.4-41.4-92.4-92.4V322.1c0-51 41.4-92.4 92.4-92.4h571.7c51 0 92.4 41.4 92.4 92.4v358.7c0 50.9-41.3 92.3-92.4 92.3z" fill="#FAFCFC" />
        <path d="M891.2 905c-2.6 0-5.2-0.7-7.5-2.1L691.6 787.6H318.4c-58.9 0-106.9-47.9-106.9-106.9V322.1c0-58.9 47.9-106.9 106.9-106.9h571.7c58.9 0 106.9 47.9 106.9 106.9v358.7c0 54-40.2 98.7-92.2 105.9l1 103.8c0 5.2-2.7 10.1-7.3 12.7-2.3 1.1-4.8 1.8-7.3 1.8zM318.4 244.2c-42.9 0-77.9 34.9-77.9 77.9v358.7c0 42.9 34.9 77.9 77.9 77.9h377.2c2.6 0 5.2 0.7 7.5 2.1l173.5 104.1-0.8-91.5c0-3.9 1.5-7.6 4.2-10.3 2.7-2.7 6.4-4.3 10.3-4.3 42.9 0 77.9-34.9 77.9-77.9V322.1c0-42.9-34.9-77.9-77.9-77.9H318.4z" fill="#154B8B" />
        <path d="M376 499.8a47.3 44.8 0 1 0 94.6 0 47.3 44.8 0 1 0-94.6 0Z" fill="#144884" />
        <path d="M557 499.8a47.3 44.8 0 1 0 94.6 0 47.3 44.8 0 1 0-94.6 0Z" fill="#144884" />
        <path d="M737.9 499.8a47.3 44.8 0 1 0 94.6 0 47.3 44.8 0 1 0-94.6 0Z" fill="#144884" /></svg>
    </div>
  </div>
</div>
<main class="grow -mt-14">
  <div class="px-4 mx-auto max-w-8xl lg:px-4">
    <div class="border-gray-200 px-2 sm:px-4 pt-2.5 rounded dark:bg-gray-900">
      <div class="mx-auto">
        <div>
          <div class="grid grid-cols-1 md:grid-cols-2 md:space-x-4">
            <div class="flex flex-col justify-between items-center p-8 bg-gray-50 rounded-lg border border-gray-200 shadow-sm dark:bg-gray-800 dark:border-gray-700 sm:flex-row">
              <form class="w-full" method="post" action="<?= admin_url('admin-post.php') ?>">
                <input type="hidden" name="action" value="pushplugin_save_prompt">
                <?php wp_nonce_field('pushplugin_save_prompt'); ?>
                <div class="mb-6">
                  <label for="heading" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Heading</label>
                  <input type="text" id="heading" name="heading" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="subheading" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Sub
                    Heading</label>
                  <input type="text" id="subheading" name="subheading" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="logo" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">logo Image
                    URL</label>
                  <input type="text" id="logo" name="logo" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="allowText" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Allow
                    Button Text</label>
                  <input type="text" id="allowText" name="allowText" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="denyText" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Deny Button
                    Text</label>
                  <input type="text" id="denyText" name="denyText" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light" required />
                </div>
                <div class="mb-6">
                  <label for="themeColor" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Theme
                    Color</label>
                  <input type="color" id="themeColor" name="themeColor" class="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 dark:shadow-sm-light h-10" required value="#1a56db" />
                </div>
                <button type="button" class="py-2.5 px-5 mr-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">Reset</button>
                <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Save
                  Prompt</button>
              </form>
            </div>
            <div id="popup-preview" class="pointer-events-none min-h-96 mt-4 md:mt-0 flex flex-col justify-between items-center bg-gray-50 rounded-lg border overflow-hidden border-gray-200 shadow-sm dark:bg-gray-800 dark:border-gray-700 sm:flex-row min-h-[500px]">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
  let iframe = document.createElement("iframe");

  let pushplugin;

  let popup_data = <?php echo json_encode($popup_data); ?>;

  const options = {
    firebaseConfig: {
      projectId: "",
      messagingSenderId: "",
      appId: "",
      apiKey: "",
    },
    domain: "",
    site_url: "",
    api_url: "",
    serviceWorker: "",
    vapid_public_key: "",
    referralCode: "",
  };

  const reset = (data = {}) => {
    popup_data = data;
    popup_data = {
      logo: popup_data.logo || "https://cdn.pushplugin.com/wordpress/v1.0.0/icon-bell.svg",
      heading: popup_data.heading || "We want to notify you about the latest updates",
      subheading: popup_data.subheading || "You can unsubscribe from notifications anytime.",
      themeColor: popup_data.themeColor || "#DF3C3D",
      allowText: popup_data.allowText || "Allow",
      denyText: popup_data.denyText || "Deny",
      desktop: popup_data.desktop || "enable",
      mobile: popup_data.mobile || "enable",
      mobileLocation: popup_data.mobileLocation || "center",
      delay: popup_data.delay || 0,
      reappear: popup_data.reappear || 0,
      bottomButton: popup_data.bottomButton || "disable",
      buttonToUnsubscribe: popup_data.buttonToUnsubscribe || "enable",
    }

    document.getElementById("logo").value = popup_data.logo;
    document.getElementById("heading").value = popup_data.heading;
    document.getElementById("subheading").value = popup_data.subheading;
    document.getElementById("themeColor").value = popup_data.themeColor;
    document.getElementById("allowText").value = popup_data.allowText;
    document.getElementById("denyText").value = popup_data.denyText;

    reloadIframe();
  };

  async function refresh() {
    document.getElementById("logo").disabled = false;
    document.getElementById("heading").disabled = false;
    document.getElementById("subheading").disabled = false;
    document.getElementById("themeColor").disabled = false;
    document.getElementById("allowText").disabled = false;
    document.getElementById("denyText").disabled = false;

    if (pushplugin?.popupIframe?.contentDocument) {
      pushplugin.popupIframe.contentDocument.querySelector(".pushplugin-optin--icon").src = popup_data.logo;
      pushplugin.popupIframe.contentDocument.querySelector(".pushplugin-optin-heading").innerHTML = popup_data.heading;
      pushplugin.popupIframe.contentDocument.querySelector(".pushplugin-optin-subheading").innerHTML = popup_data
        .subheading;
      pushplugin.popupIframe.contentDocument.querySelector(".pushplugin-optin--cta-allow").style.background = popup_data
        .themeColor;
      pushplugin.popupIframe.contentDocument.querySelector(".pushplugin-optin--cta-allow").innerHTML = popup_data
        .allowText;
      pushplugin.popupIframe.contentDocument.querySelector(".pushplugin-optin--cta-later").innerHTML = popup_data
        .denyText;
    }

    if (pushplugin) {
      await pushplugin.bottomButton("hide");
    }
  }

  function getValuesFromInput() {
    popup_data.logo = document.getElementById("logo").value;
    popup_data.heading = document.getElementById("heading").value;
    popup_data.subheading = document.getElementById("subheading").value;
    popup_data.themeColor = document.getElementById("themeColor").value;
    popup_data.allowText = document.getElementById("allowText").value;
    popup_data.denyText = document.getElementById("denyText").value;

    refresh();
  }

  function toggleView(view) {
    if (view === undefined) {
      view = $(".view").text();
    }

    if (popup_data.desktop != "enable" && popup_data.mobile != "enable") {
      refresh();
      return;
    }

    if (view == "Mobile") {
      if (popup_data.mobile != "enable") {
        alert("Mobile Prompt is Disabled, Please Enable it.");
        return;
      }
      $("#device").attr("class", "col-xl-5 mobile");
      $(".view").text("Desktop");
    } else {
      if (popup_data.desktop != "enable") {
        alert("Desktop Prompt is Disabled, Please Enable it.");
        return;
      }
      $(".view").text("Mobile");
      $("#device").attr("class", "col-xl-5 desktop");
    }
    reloadIframe();
  }

  async function reloadIframe() {
    document.getElementById("popup-preview").innerHTML = "";
    iframe = document.createElement("iframe");
    iframe.style.width = "100%";
    iframe.style.height = "100%";
    iframe.style.border = "0px";
    const content = atob("<?= $iframe_script ?>");
    iframe.srcdoc = content;
    iframe.onload = async () => {
      pushplugin = new iframe.contentWindow.PushPlugin(options, popup_data);
    };
    document.getElementById("popup-preview").appendChild(iframe);
    refresh();
  }

  function setEventListeners() {
    document.getElementById("logo").addEventListener("input", getValuesFromInput);
    document.getElementById("heading").addEventListener("input", getValuesFromInput);
    document.getElementById("subheading").addEventListener("input", getValuesFromInput);
    document.getElementById("themeColor").addEventListener("input", getValuesFromInput);
    document.getElementById("allowText").addEventListener("input", getValuesFromInput);
    document.getElementById("denyText").addEventListener("input", getValuesFromInput);
  }

  setTimeout(() => {
    reset(popup_data);
    reloadIframe();
    setEventListeners();
  }, 1000);
</script>