<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.'); ?>

<div class="mx-auto w-full logo-top text-white text-5xl font-bold text-center pt-10">
  <?php include(MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/icon.php') ?>
  <div class="px-8">
    Lets Get Started
    <p class="max-w-screen-sm mx-auto mb-20 text-lg font-light text-center opacity-70 mt-3">
      <span data-affiliate-customize="">Free for 14 days, no credit card required</span>
    </p>
  </div>
</div>
<section class="dark:bg-gray-900 -mt-14">
  <div class="flex md:flex-row justify-center px-6 pb-6 mx-auto flex-col w-full">
    <div class="w-full bg-white rounded-lg shadow dark:border md:mt-0 xl:p-0 dark:bg-gray-800 dark:border-gray-700 md:max-w-md">
      <div class="p-6 space-y-2 md:space-y-4 sm:p-8 sm:pt-4">
        <div id="message"></div>
        <form class="space-y-2 md:space-y-4" action="<?= admin_url('admin-post.php') ?>" method="post" id="login-form" autocomplete="off">
          <input type="hidden" name="action" value="pushplugin_signup_login">
          <input type="hidden" name="tab" value="login">
          <?php wp_nonce_field('pushplugin_signup_login'); ?>
          <div>
            <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Your Email</label>
            <input type="email" name="email" id="email" class="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required="" />
          </div>
          <div>
            <label for="password" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Your Password</label>
            <input type="password" name="password" id="password" class="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" required="" />
          </div>
          <div>
            <label for="license_key" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">License Key (Leave Blank for Trial)</label>
            <input type="text" name="license_key" id="license_key" class="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-xs focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" />
            <div class="opacity-60 text-xs text-right mt-1">
              <p>Don't have a license? <a href="https://pushplugin.com/pricing?utm_source=wordpress&utm_medium=plugin&utm_campaign=cta&utm_content=get_license" class="font-bold">Get one now! →</a></p>
            </div>
          </div>
          <button type="submit" class="w-full text-white bg-primary-600 hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">Login Now</button>
          <p class="text-sm font-light text-gray-500 dark:text-gray-400">Don't have an account? <a href="<?= $tab_links['signup'] ?>" class="font-medium text-primary-600 hover:underline dark:text-primary-500">Register here</a></p>
        </form>
      </div>
    </div>
    <aside class="mt-10 md:mt-28 ml-5 max-w-sm">
      <h2 class="gradient-text pb-5 text-3xl font-bold">You're in good company</h2>
      <div class="mb-3 opacity-60">
        <p>Successful websites rely on PushPlugin to send lots of push notification</a> every day.</p>
        <p>Here's some of what you're getting by signing up now…</p>
      </div>

      <ul class="ml-2 text-lg opacity-90">
        <li class="my-1 flex items-center">
          <svg class="mr-2 h-5 w-5" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <defs>
              <style>
                .fa-secondary {
                  opacity: .4
                }
              </style>
            </defs>
            <path d="M504.5 144.42L264.75 385.5 192 312.59l240.11-241a25.49 25.49 0 0 1 36.06-.14l.14.14L504.5 108a25.86 25.86 0 0 1 0 36.42z" class="fa-secondary"></path>
            <path d="M264.67 385.59l-54.57 54.87a25.5 25.5 0 0 1-36.06.14l-.14-.14L7.5 273.1a25.84 25.84 0 0 1 0-36.41l36.2-36.41a25.49 25.49 0 0 1 36-.17l.16.17z" class="fa-primary"></path>
          </svg>
          Your own push dashboard
        </li>
        <li class="my-1 flex items-center">
          <svg class="mr-2 h-5 w-5" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <!-- Font Awesome Pro 5.15.4 by @fontawesome  - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) -->
            <defs>
              <style>
                .fa-secondary {
                  opacity: .4
                }
              </style>
            </defs>
            <path d="M504.5 144.42L264.75 385.5 192 312.59l240.11-241a25.49 25.49 0 0 1 36.06-.14l.14.14L504.5 108a25.86 25.86 0 0 1 0 36.42z" class="fa-secondary"></path>
            <path d="M264.67 385.59l-54.57 54.87a25.5 25.5 0 0 1-36.06.14l-.14-.14L7.5 273.1a25.84 25.84 0 0 1 0-36.41l36.2-36.41a25.49 25.49 0 0 1 36-.17l.16.17z" class="fa-primary"></path>
          </svg>
          Send unlimited notifications
        </li>
        <li class="my-1 flex items-center">
          <svg class="mr-2 h-5 w-5" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <!-- Font Awesome Pro 5.15.4 by @fontawesome  - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) -->
            <defs>
              <style>
                .fa-secondary {
                  opacity: .4
                }
              </style>
            </defs>
            <path d="M504.5 144.42L264.75 385.5 192 312.59l240.11-241a25.49 25.49 0 0 1 36.06-.14l.14.14L504.5 108a25.86 25.86 0 0 1 0 36.42z" class="fa-secondary"></path>
            <path d="M264.67 385.59l-54.57 54.87a25.5 25.5 0 0 1-36.06.14l-.14-.14L7.5 273.1a25.84 25.84 0 0 1 0-36.41l36.2-36.41a25.49 25.49 0 0 1 36-.17l.16.17z" class="fa-primary"></path>
          </svg>
          Secured tokens to your server
        </li>
        <li class="my-1 flex items-center">
          <svg class="mr-2 h-5 w-5" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <!-- Font Awesome Pro 5.15.4 by @fontawesome  - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) -->
            <defs>
              <style>
                .fa-secondary {
                  opacity: .4
                }
              </style>
            </defs>
            <path d="M504.5 144.42L264.75 385.5 192 312.59l240.11-241a25.49 25.49 0 0 1 36.06-.14l.14.14L504.5 108a25.86 25.86 0 0 1 0 36.42z" class="fa-secondary"></path>
            <path d="M264.67 385.59l-54.57 54.87a25.5 25.5 0 0 1-36.06.14l-.14-.14L7.5 273.1a25.84 25.84 0 0 1 0-36.41l36.2-36.41a25.49 25.49 0 0 1 36-.17l.16.17z" class="fa-primary"></path>
          </svg>
          Built for wordpress users
        </li>
        <li class="my-1 flex items-center">
          <svg class="mr-2 h-5 w-5" fill="currentColor" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
            <!-- Font Awesome Pro 5.15.4 by @fontawesome  - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) -->
            <defs>
              <style>
                .fa-secondary {
                  opacity: .4
                }
              </style>
            </defs>
            <path d="M504.5 144.42L264.75 385.5 192 312.59l240.11-241a25.49 25.49 0 0 1 36.06-.14l.14.14L504.5 108a25.86 25.86 0 0 1 0 36.42z" class="fa-secondary"></path>
            <path d="M264.67 385.59l-54.57 54.87a25.5 25.5 0 0 1-36.06.14l-.14-.14L7.5 273.1a25.84 25.84 0 0 1 0-36.41l36.2-36.41a25.49 25.49 0 0 1 36-.17l.16.17z" class="fa-primary"></path>
          </svg>
          Speedy delivery
        </li>
      </ul>
    </aside>
  </div>
</section>
<script>
  function validateLoginForm() {
    document.getElementById('login-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var email = document.querySelector('input[name="email"]').value;
      var password = document.querySelector('input[name="password"]').value;

      if (email === '' || password === '') {
        showError('Please fill all the fields');
        parent.postMessage({
          action: "turnOffLoading"
        }, '*')
        return false;
      }

      function ValidateEmail(mail) {
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
          return true
        }
        return false
      }
      if (!ValidateEmail(email)) {
        showError('Please enter a valid email');
        parent.postMessage({
          action: "turnOffLoading"
        }, '*')
        return false;
      }

      this.submit();
    });
  }
  validateLoginForm();
</script>