<?php defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.');?>

<style>
  .loading {
      /* Absolute position */
      left: 0;
      position: absolute;
      top: 0;

      /* Take full size */
      height: 100%;
      width: 100%;

      /* Center */
      align-items: center;
      display: none;
      justify-content: center;
  }
  #wpbody-content {
    padding-bottom: 0 !important;
    height: calc(100vh - 32px) !important;
    display: flex !important;
    position: relative;
  }

  #wpcontent,
  #wpfooter {
    margin-left: 140px;
  }

  /* Hide the Footer */
  #wpfooter {
    display: none;
  }

  .folded #wpcontent, .folded #wpfooter{
    margin-left: 16px;
  }

  .update-nag, .notice{
    display: none;
  }

  /* Removing the left space between the nav and iframe */
  @media screen and (max-width: 782px) {
    .auto-fold #wpcontent {
      padding-left: 0px !important;
    }

    .folded #wpcontent, .folded #wpfooter{
      margin-left: 0px;
    }

    .wp-responsive-open #wpbody {
      right: -14em;
    }
  }
</style>
<!-- The iframe to load -->
<iframe id="pushplugin_frame" src="<?=$admin_ajax_url?>" style="width:100%;"></iframe>
<!-- The loading indicator -->
<div class="loading" id="pushplugin_loading">
  <?php include MY_PUSHPLUGIN_UNIQUE_PATH . 'templates/partials/loading.php'?>
</div>
<script>
  // Iframe Loading Handler - https://htmldom.dev/show-a-loading-indicator-when-an-iframe-is-being-loaded/
  // Query the elements
  const iframeEle = document.getElementById('pushplugin_frame');
  const loadingEle = document.getElementById('pushplugin_loading');

  var clickEventListener;
  var submitEventListener;

  var turnOffLoading = () => {
    loadingEle.style.display = 'none';
    iframeEle.style.background = 'rgb(255 ,255 ,255)';
    toTurnOff = false;
  }

  var turnOnLoading = () => {
    loadingEle.style.display = 'flex';
    iframeEle.style.background = 'rgba(255 ,255 ,255)';
  }

  iframeEle.addEventListener('load', function () {
      turnOffLoading();

    clickEventListener = iframeEle.contentWindow.document.addEventListener("click", function(event) {
      // check if the clicked element or one of its parents is an anchor upto 3 levels
      element = event.target;
      console.log(element)
      anchor = false;
      for (let i = 0; i < 5; i++) {
        if (element.tagName === "A" && element.target !== "_blank" && element.href !== "javascript:void(0)") {
          anchor = true;
          break;
        }
        element = element.parentElement;
      }
      console.log(anchor);
      if (anchor) {
        turnOnLoading();
      }
    });

    // Add submit event listener to all forms
    clearInterval(submitEventListener);
    submitEventListener = iframeEle.contentWindow.document.addEventListener("submit", function(event) {
      turnOnLoading();
    });
  });

  turnOnLoading();

  document.querySelector('body').classList.add('folded')

  // Add tab parameter to url
  function modifyUrl(tab) {
    var newUrl = new URL(window.location.href);
    newUrl.searchParams.set("tab", tab);
    if (window.history) {
      window.history.pushState({
        path: newUrl.href
      }, '', newUrl.href);
    }
  }

  // Listen to message from child window
  var eventMethod = window.addEventListener ?
    "addEventListener" :
    "attachEvent";
  var eventer = window[eventMethod];
  var messageEvent = eventMethod === "attachEvent" ?
    "onmessage" :
    "message";
  eventer(messageEvent, function (e) {
    if (e.data.action == "changeTab") {
      modifyUrl(e.data.tab);
    }
    if (e.data.action == "turnOffLoading") {
      turnOffLoading();
    }
    if (e.data.action == "turnOnLoading") {
      turnOnLoading();
    }
  });
</script>