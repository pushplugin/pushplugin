<?php
/**
 * @package PushPlugin
 */

/**
 * Basic Configuration for Production
 */

/**
 * Adds Notice to Complete the Setup
 *
 * @return void
 */
function add_pushplugin_setup_notice()
{
    // Check if current page is PushPlugin admin page
    $current_page = isset($_GET['page']) ? $_GET['page'] : '';
    if ($current_page == 'pushplugin') {
        return;
    }
    if ((get_option('pushplugin_settings_done', false) == false) or
        (get_option('pushplugin_prompt_done', false) == false) or
        get_option('pushplugin_token', false) == false
    ) {
        echo '<div class="notice notice-info is-dismissible">
            <p><a href="' . admin_url('admin.php?page=pushplugin') . '">Click here</a> to complete the setup of <strong>PushPlugin</strong> to start sending push notifications.</p>
        </div>';
    }
}
add_action('admin_notices', 'add_pushplugin_setup_notice');
