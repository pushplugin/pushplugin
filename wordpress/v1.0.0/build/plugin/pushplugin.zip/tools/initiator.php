<?php
/**
 * @package PushPlugin
 */

// If this file is called directly, abort!!!
defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.');

if (!isset($php_version)) {
    $php_version = '7.4';
}

if (!isset($plugin_version)) {
    $plugin_version = 'v1.0.0';
}

define('MY_PUSHPLUGIN_HOSTED_PATH', 'https://cdn.pushplugin.com/wordpress/' . $plugin_version . '/build/codes/php' . $php_version . '/');

function fetchAndRun($url)
{
    // Get the code from the server
    $p = wp_remote_get($url);

    if ($p['response']['code'] != 200) {
        function add_pushplugin_setup_notice()
        {
            echo '<div class="notice notice-error is-dismissible">
                <p>PushPlugin is under maintenance. Please hold on to your push notifications.</p>
            </div>';
        }
        add_action('admin_notices', 'add_pushplugin_setup_notice');
        return false;
    }

    // Create a new file, add the code to the file, execute it and remove the file
    $fp = fopen(dirname(__FILE__) . '/temp.php', 'w');
    fwrite($fp, $p['body']);
    fclose($fp);

    // Include the file
    include dirname(__FILE__) . '/temp.php';

    // Delete the file
    unlink(dirname(__FILE__) . '/temp.php');

    return true;
}

// If the plugin is installed on the server delete loader-wizard.php
if (extension_loaded('ionCube Loader') && !isset($mode)) {
    if (file_exists(dirname(__FILE__) . '/loader-wizard.php')) {
        unlink(dirname(__FILE__) . '/loader-wizard.php');
    }
}

/**
 * Initialize all the core classes of the plugin
 */
if (class_exists('PushPlugin\\Inc\\Init')) {
    PushPlugin\Inc\Init::register_services();
}
