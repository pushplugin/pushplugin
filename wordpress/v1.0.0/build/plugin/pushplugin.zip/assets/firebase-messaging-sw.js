var swVersion = "3.0.0";
const firebaseVersion = "8.9.1";

importScripts(
  "https://www.gstatic.com/firebasejs/" + firebaseVersion + "/firebase-app.js"
);
importScripts(
  "https://www.gstatic.com/firebasejs/" +
    firebaseVersion +
    "/firebase-messaging.js"
);

const options = {
  firebaseConfig: {
    projectId: "FIREBASE_PROJECT_ID",
    messagingSenderId: "FIREBASE_MESSAGING_SENDER_ID",
    appId: "FIREBASE_APP_ID",
    apiKey: "FIREBASE_API_KEY",
  },
};

firebase.initializeApp({
  ...options.firebaseConfig,
});

self.addEventListener("activate", function (a) {
  a.waitUntil(clients.claim());
});
self.addEventListener("install", function (i) {
  self.skipWaiting();
});

/**
 * Receives push notification.
 *
 * Shows the notification to the user.
 */
self.addEventListener("push", (event) => {
  const payload = JSON.parse(event.data.json().data.notification);
  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      icon: payload.icon,
      image: payload.image,
      data: payload,
      ...payload,
    })
  );

  if (event.data.json().data.swVersion != swVersion) {
    console.log("SW Version is different, Updating SW");
    self.registration.update();
  }
});

/**
 * Gets called when notification is clicked.
 *
 * Opens a new tab in browser.
 */
self.addEventListener("notificationclick", (event) => {
  if (event.action == "") {
    clients.openWindow(event.notification.data.url);
    fetch(event.notification.data.api_url);
  } else {
    clients.openWindow(
      event.notification.data.actions[event.action].click_action
    );
    fetch(event.notification.data.actions[event.action].api_url);
  }
});

/** ================= FOR AMP ================ */

/** @enum {string} */
const WorkerMessengerCommand = {
  /*
      Used to request the current subscription state.
     */
  AMP_SUBSCRIPTION_STATE: "amp-web-push-subscription-state",
  /*
      Used to request the service worker to subscribe the user to push.
      Notification permissions are already granted at this point.
     */
  AMP_SUBSCRIBE: "amp-web-push-subscribe",
  /*
      Used to unsusbcribe the user from push.
     */
  AMP_UNSUBSCRIBE: "amp-web-push-unsubscribe",
};

self.addEventListener("message", (event) => {
  /*
      Messages sent from amp-web-push have the format:
  
      - command: A string describing the message topic (e.g.
        'amp-web-push-subscribe')
  
      - payload: An optional JavaScript object containing extra data relevant to
        the command.
     */
  const { command } = event.data;

  switch (command) {
    case WorkerMessengerCommand.AMP_SUBSCRIPTION_STATE:
      onMessageReceivedSubscriptionState();
      break;
    case WorkerMessengerCommand.AMP_SUBSCRIBE:
      onMessageReceivedSubscribe();
      break;
    case WorkerMessengerCommand.AMP_UNSUBSCRIBE:
      onMessageReceivedUnsubscribe();
      break;
  }
});

/**
 * Broadcasts a single boolean describing whether the user is subscribed.
 */
function onMessageReceivedSubscriptionState() {
  let retrievedPushSubscription = null;
  self.registration.pushManager
    .getSubscription()
    .then((pushSubscription) => {
      retrievedPushSubscription = pushSubscription;
      if (!pushSubscription) {
        return null;
      } else {
        return self.registration.pushManager.permissionState(
          pushSubscription.options
        );
      }
    })
    .then((permissionStateOrNull) => {
      if (permissionStateOrNull == null) {
        broadcastReply(WorkerMessengerCommand.AMP_SUBSCRIPTION_STATE, false);
      } else {
        const isSubscribed =
          !!retrievedPushSubscription && permissionStateOrNull === "granted";
        broadcastReply(
          WorkerMessengerCommand.AMP_SUBSCRIPTION_STATE,
          isSubscribed
        );
      }
    });
}

/**
 * Sends a postMessage() to all window frames the service worker controls.
 * @param {string} command
 * @param {!JsonObject} payload
 */
function broadcastReply(command, payload) {
  self.clients.matchAll().then((clients) => {
    for (let i = 0; i < clients.length; i++) {
      const client = clients[i];
      client./*OK*/ postMessage({
        command,
        payload,
      });
    }
  });
}
