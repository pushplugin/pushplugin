<?php

/**
 * Plugin Name: PushPlugin
 * Plugin URI: https://PushPlugin.com
 * Description: The Perfect Push Notification Plugin for WordPress. 👌
 * Version: 1.0.0
 * Author: PushPlugin
 * Author URI: https://pushplugin.com
 * License: N/A
 * License URI: N/A
 * Text Domain: pushplugin
 *
 *
 * ██████╗ ██╗   ██╗███████╗██╗  ██╗    ██████╗ ██╗     ██╗   ██╗ ██████╗ ██╗███╗   ██╗
 * ██╔══██╗██║   ██║██╔════╝██║  ██║    ██╔══██╗██║     ██║   ██║██╔════╝ ██║████╗  ██║
 * ██████╔╝██║   ██║███████╗███████║    ██████╔╝██║     ██║   ██║██║  ███╗██║██╔██╗ ██║
 * ██╔═══╝ ██║   ██║╚════██║██╔══██║    ██╔═══╝ ██║     ██║   ██║██║   ██║██║██║╚██╗██║
 * ██║     ╚██████╔╝███████║██║  ██║    ██║     ███████╗╚██████╔╝╚██████╔╝██║██║ ╚████║
 * ╚═╝      ╚═════╝ ╚══════╝╚═╝  ╚═╝    ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝ ╚═╝╚═╝  ╚═══╝
 *
 * The Perfect Push Notification Plugin for WordPress.👌
 *
 * Hi Developer 🙋‍♂️,
 * We tried to keep the price of the plugin as low as possible. So that everyone can afford it. Please don't crack the plugin. We are happy to announce that we have launched a bug bounty program for PushPlugin. You can read more about the program here:
 * https://pushplugin.com/bug-bounty-program/
 *
 * We request you to ask your client to purchase the plugin. If you are a freelancer, you can purchase the plugin for your client. We are happy to help you. You can contact us at
 * https://pushplugin.com/contact/
 *
 * Thanks,
 * PushPlugin Team
 *
 *                                                             ((((((((((((%
 *                                                           ((((((((((((((((%
 *                                                          ((((((((((((((((((%
 *             &((((((((((((((((((((((((((((((((((((((((   %((((((((((((((((((%
 *      %#((((((((((((((((((((((((((((((((((((((((((((((    ((((((((((((((((((%
 *    (((%&((((((((((((((((((((((((((((((((((((((((((((((    ((((((((((((((((
 *  #((  &((((((((((((((((((((((((((((((((((((((((((((((((     %(((((((((((&
 * (((   %((((((((((((((((((((((((((((((((((((((((((((((((((%
 * ((#   %((((((((((((((((((((((((((((((((((((((((((((((((((((((#
 * ((    %((((((((((((((((((((                      ((((((((((((((((((((&
 * ((    %((((((((((((((((((%                        #((((((((((((((((((&
 * ((    %((((((((((((((((((%                        #((((((((((((((((((&
 * ((    %((((((((((((((((((%                        #((((((((((((((((((&
 * ((    %((((((((((((((((((%                        #((((((((((((((((((&
 * ((    %((((((((((((((((((%                        #((((((((((((((((((&
 * ((    %((((((((((((((((((%                      #((((((((((((((((((((&
 * ((    %((((((((((((((((((%       #(((((((((((((((((((((((((((((((((((&
 * ((    %((((((((((((((((((%  %((((((((((((((((((((((((((((((((((((((((&
 * ((    %(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((%
 * ((    %((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((
 * ((    %((((((((((((((((((((((((((((((((((((((((((((((((((((((((((
 * ((    %(((((((((((((((((((((((((((((((((((((((((((((((((((((
 * ((    %(((((((((((((((((((((((((&&
 * ((    %((((((((((((((((((&
 * ((    %(((((((((((((%
 * ((    ((((((((((#
 * (((((((((((((
 *
 * ====================== PushPlugin Plugin License Start =========================
 * Copyright (c) 2023 PushPlugin
 *
 * This program is paid software; you can't redistribute or  modify
 * it. Please Find the full license at https://pushplugin.com/license
 *
 * If you can't find the PushPlugin Plugin License on the given link
 * please write to PushPlugin Support at https://pushplugin.com/contact
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *=========================== PushPlugin Plugin License Ends =====================
 */

defined('ABSPATH') or die('Hey, Thankyou for doing this research. If you find any bug in the plugin. Please contact us at admin@pushplugin.com. We also provide bug bounty on the research.');

// Require once the Composer Autoload
if (file_exists(dirname(__FILE__) . '/vendor/autoload.php')) {
    require_once dirname(__FILE__) . '/vendor/autoload.php';
}

/**
 * Constants for the plugin
 */
$url = plugin_dir_url(__FILE__);
define('MY_PUSHPLUGIN_UNIQUE_URL', $url);

$path = plugin_dir_path(__FILE__);
define('MY_PUSHPLUGIN_UNIQUE_PATH', $path);

/**
 * The code that runs during plugin activation
 */
function activate_pushplugin() {
    PushPlugin\Inc\Base\PushPluginActivate::activate();
}
register_activation_hook(__FILE__, 'activate_pushplugin');



/**
 * The code that runs during plugin deactivation
 */
function deactivate_pushplugin() {
    PushPlugin\Inc\Base\PushPluginDeactivate::deactivate();
}
register_deactivation_hook(__FILE__, 'deactivate_pushplugin');



/**
 * Check if the plugin is in development mode
 */
if (file_exists(dirname(__FILE__) . '/tools/development.php')) {
    require_once dirname(__FILE__) . '/tools/development.php';
} else {
    require_once dirname(__FILE__) . '/tools/production.php';
}


require plugin_dir_path(__FILE__) . '/tools/initiator.php';